import flask
from flask import Flask,render_template,request,url_for
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler,LabelEncoder
from sklearn import preprocessing

app=Flask(__name__)
@app.route('/')
def Hello_world():
    return render_template('home.html')
@app.route('/predict')
def home():
    return render_template('index.html')
@app.route('/output',methods=['POST','GET'])
def predict():
    if request.method=="POST":
        ID=request.form['ID']
        Gender=request.form['gender']
        Age=request.form['age']
        Height=request.form['height(cm)']
        Weight=request.form['weight(Kg)']
        Waist=request.form['waist(cm)']
        Eyesight_left=request.form['eyesight(left)']
        Eyesight_right=request.form['eyesight(right)']
        Hearing_left=request.form['hearing(left)']
        Hearing_right=request.form['hearing(right)']
        systolic=request.form['systolic']
        relaxation=request.form['relaxation']
        fasting_blood_sugar=request.form['fasting_blood_sugar']
        Cholesterol=request.form['Cholesterol']
        triglyceride=request.form['triglyceride']
        HDL=request.form['HDL']
        LDL=request.form['LDL']
        Hemoglobin=request.form['hemoglobin']
        urine_protein=request.form['Urine_protein']
        serum_creatinine=request.form['serum_creatinine']
        AST=request.form['AST']
        ALT=request.form['ALT']
        Gtp=request.form['Gtp']
        oral=request.form['oral']
        dental_caries=request.form['dental_caries']
        tartar=request.form['tartar']
        input=[[float(ID),float(Gender),float(Age),float(Height),float(Weight),float(Waist),float(Eyesight_left),float(Eyesight_right),float(Hearing_left),
                float(Hearing_right),float(systolic),float(relaxation),float(fasting_blood_sugar),float(Cholesterol),float(triglyceride),float(HDL),float(LDL),
                float(Hemoglobin),float(urine_protein),float(serum_creatinine),float(AST),float(ALT),float(Gtp),float(oral),float(dental_caries),float(tartar)]]          
        #Handling Missing Values
               
        model=pickle.load(open('smoke_model.pkl','rb'))
        names=[['ID','gender','age','height(cm)','weight(kg)','waist(cm)','eyesight(left)','eyesight(right)',
                'hearing(left)','hearing(right)','systolic','relaxation','fasting_blood_sugar','Cholesterol',
                'triglyceride','HDL','LDL','hemoglobin','Urine_protein','serum creatinine','AST','ALT',
                'Gtp','oral','dental_caries','tartar']]
        final=[np.array(input)]
        data=pd.DataFrame(final,columns=names)
        scale=StandardScaler()
        data=scale.fit_transform(final)
        label_encoder = preprocessing.LabelEncoder() 
        # Encode labels in column 'gender'. 
        data['gender']= label_encoder.fit_transform(data['gender']) 
        data['gender'].unique() 
        data['oral']= label_encoder.fit_transform(data['oral']) 
        data['oral'].unique() 
        data['tartar']= label_encoder.fit_transform(data['tartar']) 
        data['tartar'].unique() 
        prediction=model.predict(data)[0]
        if prediction==0 :
            return render_template('/smoke_predict.html',pred="0")
    #rendering
    return render_template('precautions.html',pred="1")
if __name__=='__main__':
    app.run(debug=True)
